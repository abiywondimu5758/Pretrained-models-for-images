# Animal dataset annotation > 2025-04-19 12:50pm
https://universe.roboflow.com/animal-detection-using-yolov5/animal-dataset-annotation

Provided by a Roboflow user
License: Public Domain

